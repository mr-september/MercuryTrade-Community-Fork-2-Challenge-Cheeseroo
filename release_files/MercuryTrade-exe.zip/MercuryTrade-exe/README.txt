Here you can put your own sound files to change existing ones.

Simply put a sound file inside this folder and name it like the one which is used in MT. 


The list of files which MT uses has names:
button-pressed.wav
chat-filter.wav
icq-message.wav
notification.wav
patch_tone.wav

Also if you want to change betrayal image to any you need just replace "helpIGImg.png" with any image with same name

All files that you want to change need to be in location resources/app